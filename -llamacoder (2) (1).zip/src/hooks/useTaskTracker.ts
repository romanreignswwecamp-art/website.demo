import { useState, useEffect, useCallback } from 'react';
import { Task } from '../types';

const STORAGE_KEY = 'trackflow-tasks';

export function useTaskTracker() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsedTasks = JSON.parse(stored);
      setTasks(parsedTasks);
      
      const runningTask = parsedTasks.find((t: Task) => t.isRunning);
      if (runningTask) {
        setActiveTaskId(runningTask.id);
      }
    }
  }, []);

  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    }
  }, [tasks]);

  useEffect(() => {
    if (!activeTaskId) return;

    const interval = setInterval(() => {
      setTasks(prevTasks => 
        prevTasks.map(task => {
          if (task.id === activeTaskId && task.isRunning && task.startTime) {
            return { ...task, endTime: Date.now() };
          }
          return task;
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [activeTaskId]);

  const createTask = useCallback((name: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      name,
      startTime: null,
      endTime: null,
      duration: 0,
      isRunning: false,
      entries: []
    };
    setTasks(prev => [...prev, newTask]);
  }, []);

  const startTask = useCallback((taskId: string) => {
    setTasks(prevTasks => 
      prevTasks.map(task => {
        if (task.id === taskId) {
          return {
            ...task,
            startTime: Date.now(),
            endTime: null,
            isRunning: true
          };
        }
        if (task.isRunning) {
          const sessionDuration = Date.now() - (task.startTime || Date.now());
          return {
            ...task,
            duration: task.duration + sessionDuration,
            endTime: Date.now(),
            isRunning: false,
            entries: [...task.entries, {
              startTime: task.startTime || Date.now(),
              endTime: Date.now()
            }]
          };
        }
        return task;
      })
    );
    setActiveTaskId(taskId);
  }, []);

  const pauseTask = useCallback((taskId: string) => {
    setTasks(prevTasks => 
      prevTasks.map(task => {
        if (task.id === taskId && task.isRunning && task.startTime) {
          const sessionDuration = Date.now() - task.startTime;
          return {
            ...task,
            duration: task.duration + sessionDuration,
            endTime: Date.now(),
            isRunning: false,
            entries: [...task.entries, {
              startTime: task.startTime,
              endTime: Date.now()
            }]
          };
        }
        return task;
      })
    );
    setActiveTaskId(null);
  }, []);

  const deleteTask = useCallback((taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    if (activeTaskId === taskId) {
      setActiveTaskId(null);
    }
  }, [activeTaskId]);

  const renameTask = useCallback((taskId: string, newName: string) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === taskId ? { ...task, name: newName } : task
      )
    );
  }, []);

  const getTodayTasks = useCallback(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return tasks.filter(task => {
      return task.entries.some(entry => {
        const entryDate = new Date(entry.startTime);
        entryDate.setHours(0, 0, 0, 0);
        return entryDate.getTime() === today.getTime();
      }) || (task.isRunning && task.startTime && new Date(task.startTime) >= today);
    });
  }, [tasks]);

  return {
    tasks,
    activeTaskId,
    createTask,
    startTask,
    pauseTask,
    deleteTask,
    renameTask,
    getTodayTasks
  };
}