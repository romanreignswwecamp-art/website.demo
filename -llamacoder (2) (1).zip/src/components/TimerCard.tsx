import { Task } from '../types';
import { Play, Pause, Trash, Edit } from 'lucide-react';
import { Button } from '/components/ui/button';
import { Input } from '/components/ui/input';
import { useState } from 'react';

interface TimerCardProps {
  task: Task;
  isActive: boolean;
  onStart: () => void;
  onPause: () => void;
  onDelete: () => void;
  onRename: (newName: string) => void;
}

export function TimerCard({ task, isActive, onStart, onPause, onDelete, onRename }: TimerCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(task.name);
  
  const currentDuration = task.duration + (task.isRunning && task.startTime ? Date.now() - task.startTime : 0);
  const formattedTime = formatDuration(currentDuration);
  
  const handleRename = () => {
    if (editName.trim()) {
      onRename(editName.trim());
      setIsEditing(false);
    }
  };
  
  return (
    <div className={`bg-white border-2 rounded-xl p-4 transition-all duration-200 ${
      isActive ? 'border-blue-500 shadow-md' : 'border-gray-200 hover:border-gray-300'
    }`}>
      <div className="flex items-center justify-between">
        <div className="flex-1 mr-4">
          {isEditing ? (
            <div className="flex gap-2">
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                onBlur={handleRename}
                onKeyDown={(e) => e.key === 'Enter' && handleRename()}
                className="h-8"
                autoFocus
              />
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <h3 className="font-medium text-gray-900">{task.name}</h3>
              <button
                onClick={() => setIsEditing(true)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <Edit className="w-3 h-3 text-gray-400" />
              </button>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <span className={`font-mono text-lg ${isActive ? 'text-blue-600' : 'text-gray-700'}`}>
            {formattedTime}
          </span>
          
          <div className="flex items-center gap-1">
            {isActive ? (
              <Button
                size="sm"
                variant="outline"
                onClick={onPause}
                className="h-8 w-8 p-0"
              >
                <Pause className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                size="sm"
                onClick={onStart}
                className="h-8 w-8 p-0 bg-blue-500 hover:bg-blue-600"
              >
                <Play className="w-4 h-4 ml-0.5" />
              </Button>
            )}
            
            <Button
              size="sm"
              variant="ghost"
              onClick={onDelete}
              className="h-8 w-8 p-0 text-gray-400 hover:text-red-500 hover:bg-red-50"
            >
              <Trash className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      {isActive && (
        <div className="mt-3 h-1 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-blue-500 animate-pulse w-full" />
        </div>
      )}
    </div>
  );
}

function formatDuration(ms: number): string {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}