import { Button } from '/components/ui/button';
import { Download } from 'lucide-react';
import { useState } from 'react';

interface ExportButtonProps {
  onExport: () => void;
}

export function ExportButton({ onExport }: ExportButtonProps) {
  const [showToast, setShowToast] = useState(false);
  
  const handleExport = () => {
    onExport();
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };
  
  return (
    <div className="relative">
      <Button
        onClick={handleExport}
        variant="outline"
        className="gap-2"
      >
        <Download className="w-4 h-4" />
        Export Today
      </Button>
      
      {showToast && (
        <div className="absolute top-full mt-2 left-0 right-0 bg-gray-900 text-white text-sm py-2 px-4 rounded-lg text-center animate-in fade-in slide-in-from-top-2">
          CSV exported successfully!
        </div>
      )}
    </div>
  );
}