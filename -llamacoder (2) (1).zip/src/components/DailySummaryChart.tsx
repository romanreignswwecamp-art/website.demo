import { Task } from '../types';

interface DailySummaryChartProps {
  tasks: Task[];
}

export function DailySummaryChart({ tasks }: DailySummaryChartProps) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const todayTasks = tasks
    .map(task => {
      const todayDuration = task.entries.reduce((acc, entry) => {
        const entryDate = new Date(entry.startTime);
        entryDate.setHours(0, 0, 0, 0);
        
        if (entryDate.getTime() === today.getTime()) {
          return acc + (entry.endTime ? entry.endTime - entry.startTime : 0);
        }
        return acc;
      }, 0);
      
      if (task.isRunning && task.startTime) {
        const startDate = new Date(task.startTime);
        startDate.setHours(0, 0, 0, 0);
        if (startDate.getTime() === today.getTime()) {
          return { ...task, todayDuration: todayDuration + (Date.now() - task.startTime) };
        }
      }
      
      return { ...task, todayDuration };
    })
    .filter(task => task.todayDuration > 0)
    .sort((a, b) => b.todayDuration - a.todayDuration);
  
  const totalMs = todayTasks.reduce((acc, task) => acc + task.todayDuration, 0);
  const maxDuration = Math.max(...todayTasks.map(t => t.todayDuration), 1);
  
  const totalHours = Math.floor(totalMs / 3600000);
  const totalMinutes = Math.floor((totalMs % 3600000) / 60000);
  
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900">Today's Summary</h2>
        <div className="text-right">
          <span className="text-2xl font-bold text-gray-900">
            {totalHours}h {totalMinutes}m
          </span>
          <p className="text-sm text-gray-500">Total time</p>
        </div>
      </div>
      
      {todayTasks.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <p>No time logged today</p>
        </div>
      ) : (
        <div className="space-y-4">
          {todayTasks.map((task) => {
            const percentage = (task.todayDuration / maxDuration) * 100;
            const hours = Math.floor(task.todayDuration / 3600000);
            const minutes = Math.floor((task.todayDuration % 3600000) / 60000);
            
            return (
              <div key={task.id} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-700 font-medium">{task.name}</span>
                  <span className="text-gray-500">
                    {hours > 0 ? `${hours}h ` : ''}{minutes}m
                  </span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-400 to-teal-400 rounded-full transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}