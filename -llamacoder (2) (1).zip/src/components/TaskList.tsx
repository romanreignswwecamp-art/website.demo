import { Task } from '../types';
import { TimerCard } from './TimerCard';
import { Button } from '/components/ui/button';
import { Input } from '/components/ui/input';
import { useState } from 'react';

interface TaskListProps {
  tasks: Task[];
  activeTaskId: string | null;
  onStartTask: (id: string) => void;
  onPauseTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onRenameTask: (id: string, name: string) => void;
  onCreateTask: (name: string) => void;
}

export function TaskList({
  tasks,
  activeTaskId,
  onStartTask,
  onPauseTask,
  onDeleteTask,
  onRenameTask,
  onCreateTask
}: TaskListProps) {
  const [newTaskName, setNewTaskName] = useState('');
  
  const handleCreateTask = () => {
    if (newTaskName.trim()) {
      onCreateTask(newTaskName.trim());
      setNewTaskName('');
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="space-y-3">
        {tasks.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p className="text-lg">No tasks yet</p>
            <p className="text-sm">Create your first task below</p>
          </div>
        ) : (
          tasks.map(task => (
            <TimerCard
              key={task.id}
              task={task}
              isActive={activeTaskId === task.id}
              onStart={() => onStartTask(task.id)}
              onPause={() => onPauseTask(task.id)}
              onDelete={() => onDeleteTask(task.id)}
              onRename={(name) => onRenameTask(task.id, name)}
            />
          ))
        )}
      </div>
      
      <div className="flex gap-2 pt-2">
        <Input
          placeholder="New task name..."
          value={newTaskName}
          onChange={(e) => setNewTaskName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleCreateTask()}
          className="flex-1"
        />
        <Button onClick={handleCreateTask} className="bg-blue-500 hover:bg-blue-600">
          Add Task
        </Button>
      </div>
    </div>
  );
}