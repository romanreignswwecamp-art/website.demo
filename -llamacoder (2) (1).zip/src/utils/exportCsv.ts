import { Task } from '../types';

export function exportDailyTasks(tasks: Task[]): string {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const csvRows: string[] = [];
  csvRows.push('Task Name,Start Time,End Time,Duration,Date');
  
  tasks.forEach(task => {
    task.entries.forEach(entry => {
      const entryDate = new Date(entry.startTime);
      entryDate.setHours(0, 0, 0, 0);
      
      if (entryDate.getTime() === today.getTime()) {
        const startTime = new Date(entry.startTime).toLocaleTimeString();
        const endTime = entry.endTime ? new Date(entry.endTime).toLocaleTimeString() : 'Running';
        const duration = formatDuration(entry.endTime ? entry.endTime - entry.startTime : Date.now() - entry.startTime);
        const date = new Date(entry.startTime).toLocaleDateString();
        
        csvRows.push(`"${task.name}",${startTime},${endTime},${duration},${date}`);
      }
    });
  });
  
  return csvRows.join('\n');
}

function formatDuration(ms: number): string {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  return `${hours}h ${minutes}m`;
}

export function downloadCsv(csvContent: string, filename: string) {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}