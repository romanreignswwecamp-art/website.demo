import { useTaskTracker } from './hooks/useTaskTracker';
import { TaskList } from './components/TaskList';
import { DailySummaryChart } from './components/DailySummaryChart';
import { ExportButton } from './components/ExportButton';
import { exportDailyTasks, downloadCsv } from './utils/exportCsv';
import { Clock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '/components/ui/card';

function App() {
  const {
    tasks,
    activeTaskId,
    createTask,
    startTask,
    pauseTask,
    deleteTask,
    renameTask,
    getTodayTasks
  } = useTaskTracker();
  
  const handleExport = () => {
    const todayTasks = getTodayTasks();
    const csvContent = exportDailyTasks(todayTasks);
    const today = new Date().toISOString().split('T')[0];
    downloadCsv(csvContent, `trackflow-${today}.csv`);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-blue-500 p-2 rounded-lg">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">TrackFlow</h1>
                <p className="text-sm text-gray-500">Professional Time Tracker</p>
              </div>
            </div>
            <ExportButton onExport={handleExport} />
          </div>
        </header>
        
        <div className="space-y-6">
          <DailySummaryChart tasks={tasks} />
          
          <Card>
            <CardHeader>
              <CardTitle>Tasks</CardTitle>
              <CardDescription>
                Track time for your tasks. Only one timer can run at a time.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <TaskList
                tasks={tasks}
                activeTaskId={activeTaskId}
                onStartTask={startTask}
                onPauseTask={pauseTask}
                onDeleteTask={deleteTask}
                onRenameTask={renameTask}
                onCreateTask={createTask}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default App;