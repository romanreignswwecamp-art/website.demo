export interface Task {
  id: string;
  name: string;
  startTime: number | null;
  endTime: number | null;
  duration: number;
  isRunning: boolean;
  entries: TimeEntry[];
}

export interface TimeEntry {
  startTime: number;
  endTime: number | null;
}